package com.example.hw13demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hw13demoApplicationTests {

    @Test
    void contextLoads() {
    }

}
