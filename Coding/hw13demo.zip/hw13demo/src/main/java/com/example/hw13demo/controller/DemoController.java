package com.example.hw13demo.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class DemoController {

    private final RestTemplate restTemplate;

    public DemoController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @GetMapping("/hello")
    public ResponseEntity<Map<String, Object>> hello(@RequestParam(defaultValue = "Angelina") String name) {
        return ResponseEntity.ok(Map.of("message", "Hello " + name));
    }

    @GetMapping("/external")
    public ResponseEntity<String> externalCall() {
        String url = "https://httpbin.org/get";
        String body = restTemplate.getForObject(url, String.class);
        return ResponseEntity.ok(body);
    }

    @GetMapping("/boom")
    public ResponseEntity<String> boom() {
        throw new RuntimeException("Intentional error for AOP test");
    }
}
