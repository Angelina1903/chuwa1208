package com.example.hw13demo.aop;

import jakarta.servlet.http.HttpServletRequest;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.Arrays;

@Aspect
@Component
public class AopLoggerAspect {

    private HttpServletRequest currentRequestOrNull() {
        RequestAttributes attrs = RequestContextHolder.getRequestAttributes();
        if (attrs instanceof ServletRequestAttributes sra) {
            return sra.getRequest();
        }
        return null;
    }

    // 1) BEFORE: log request details + args
    @Before("execution(* com.example.hw13demo.controller..*(..))")
    public void beforeController(JoinPoint jp) {
        HttpServletRequest req = currentRequestOrNull();
        String sig = jp.getSignature().toShortString();

        if (req != null) {
            System.out.println("[AOP-BEFORE] " + sig
                    + " | " + req.getMethod() + " " + req.getRequestURI()
                    + (req.getQueryString() == null ? "" : "?" + req.getQueryString())
                    + " | args=" + Arrays.toString(jp.getArgs()));
        } else {
            System.out.println("[AOP-BEFORE] " + sig + " | args=" + Arrays.toString(jp.getArgs()));
        }
    }

    // 2) AFTER: always runs
    @After("execution(* com.example.hw13demo.controller..*(..))")
    public void afterController(JoinPoint jp) {
        System.out.println("[AOP-AFTER] " + jp.getSignature().toShortString());
    }

    // 3) AFTER RETURNING: log response details
    @AfterReturning(pointcut = "execution(* com.example.hw13demo.controller..*(..))", returning = "ret")
    public void afterReturningController(JoinPoint jp, Object ret) {
        String sig = jp.getSignature().toShortString();
        if (ret instanceof ResponseEntity<?> re) {
            System.out.println("[AOP-AFTER-RETURNING] " + sig
                    + " | status=" + re.getStatusCode()
                    + " | body=" + safeToString(re.getBody()));
        } else {
            System.out.println("[AOP-AFTER-RETURNING] " + sig + " | return=" + safeToString(ret));
        }
    }

    // 4) AFTER THROWING: log exception
    @AfterThrowing(pointcut = "execution(* com.example.hw13demo.controller..*(..))", throwing = "ex")
    public void afterThrowingController(JoinPoint jp, Throwable ex) {
        System.out.println("[AOP-AFTER-THROWING] " + jp.getSignature().toShortString()
                + " | ex=" + ex.getClass().getSimpleName()
                + " | msg=" + ex.getMessage());
    }

    // 5) AROUND: method execution time (for your code)
    @Around("execution(* com.example.hw13demo..*(..))")
    public Object timeAllYourCode(ProceedingJoinPoint pjp) throws Throwable {
        long start = System.nanoTime();
        try {
            return pjp.proceed();
        } finally {
            long ms = (System.nanoTime() - start) / 1_000_000;
            System.out.println("[AOP-AROUND] " + pjp.getSignature().toShortString()
                    + " | time=" + ms + "ms");
        }
    }

    // 6) External code: RestTemplate methods
    @Around("execution(* org.springframework.web.client.RestTemplate.*(..))")
    public Object logRestTemplate(ProceedingJoinPoint pjp) throws Throwable {
        long start = System.nanoTime();
        try {
            Object res = pjp.proceed();
            long ms = (System.nanoTime() - start) / 1_000_000;
            System.out.println("[AOP-EXTERNAL] " + pjp.getSignature().toShortString()
                    + " | args=" + Arrays.toString(pjp.getArgs())
                    + " | time=" + ms + "ms");
            return res;
        } catch (Throwable ex) {
            long ms = (System.nanoTime() - start) / 1_000_000;
            System.out.println("[AOP-EXTERNAL] " + pjp.getSignature().toShortString()
                    + " | time=" + ms + "ms"
                    + " | ex=" + ex.getClass().getSimpleName()
                    + " | msg=" + ex.getMessage());
            throw ex;
        }
    }

    private String safeToString(Object obj) {
        if (obj == null) return "null";
        String s = obj.toString();
        return s.length() > 400 ? s.substring(0, 400) + "...(truncated)" : s;
    }
}
