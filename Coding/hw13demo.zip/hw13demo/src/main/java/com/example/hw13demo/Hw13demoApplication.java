package com.example.hw13demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hw13demoApplication {

    public static void main(String[] args) {
        SpringApplication.run(Hw13demoApplication.class, args);
    }

}
